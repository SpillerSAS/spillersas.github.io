#Carlin, Jiang, & Spiller
#Millennial-Style Learning: Search Intensity, Decision-Making, and Information-Sharing
#Management Science
#Code to generate statistics, tables, and figures reported in manuscript

library(ggplot2)
library(boot)
library(dplyr)
library(psych)

rm(list=ls())
eps<-.Machine$double.eps ^ .5

#Import data. Adjust working directory as needed. See paper, README.txt, and Codebook.xlsx for details on variables.
d<-read.csv("CJSData.csv")

####Calculations of log-transformed attention variables####
#Calculate log-transformed time and view variables
d$LnTimeDomCard<-log(1+d$TimeDomCard)
d$LnTimeActCard<-log(1+d$TimeActCard)
d$LnTimeFixCard<-log(1+d$TimeFixCard)
d$LnTimeAPRCard<-log(1+d$TimeAPRCard)

d$LnViewDomCard<-log(1+d$ViewDomCard)
d$LnViewActCard<-log(1+d$ViewActCard)
d$LnViewFixCard<-log(1+d$ViewFixCard)
d$LnViewAPRCard<-log(1+d$ViewAPRCard)

#Calculate average and difference variables
d$AvgLnTime<-(d$LnTimeDomCard+d$LnTimeActCard+d$LnTimeFixCard+d$LnTimeAPRCard)/4
d$AvgOtherLnTime<-(d$LnTimeActCard+d$LnTimeFixCard+d$LnTimeAPRCard)/3
d$DiffLnTime<-d$LnTimeDomCard-d$AvgOtherLnTime

d$AvgLnView<-(d$LnViewDomCard+d$LnViewActCard+d$LnViewFixCard+d$LnViewAPRCard)/4
d$AvgOtherLnView<-(d$LnViewActCard+d$LnViewFixCard+d$LnViewAPRCard)/3
d$DiffLnView<-d$LnViewDomCard-d$AvgOtherLnView

####Demographics summary, Table 2####
#Male = 1, Female = 2
table(d$Sex)

summary(d$Age)
summary(subset(d,Age<200)$Age)
table(d$AgeBin)

#Bins of <$25K, 25-49K, 50-74K, 75-99K, 100-149K, >=150K
summary(d$income)
table(d$income)

#High school/GED; some college; 2-year degree; 4-year degree; master's degree; doctoral degree; professional degree
summary(d$Edu)
table(d$Edu)

#Max frequency (Never, <1/month, 1/month, 2-3/month, 1/week, 2-3/week, daily) across media
table(pmax(d$Frequency_1,d$Frequency_2,d$Frequency_3,d$Frequency_4,d$Frequency_5,d$Frequency_6,na.rm=T))

#Has credit card, number of cards
table(d$HaveCard)
table(d$NCard)

####Comprehension and Memory Checks, Table 3, Table 4####

#Choice of dominant card when all diagnostic information salient 
#as a function of Video (.5 = Implemental, -.5 = Baseline) and Ad (.5 = Superfluous, -.5 = None)
summary(glm(ChoseSalTarget~VidCon*AdCon,data=d,family="binomial"))
xtabs(~d$ChoseSalTarget+d$Video)

#Memory accuracy for 9 attribute values as a function of Video and Ad
summary(lm(TotMemAttAcc~VidCon*AdCon,data=d))

#Memory accuracy for key issues in video as a function of Video and Ad
summary(lm(MemIssAcc~VidCon*AdCon,data=d))

#Table 3 choice when all diagnostic information salient
table(d$ChoseSalCat)

#Table 4
#Memory accuracy (0/1) for each attribute value
summary(cbind(d$MemAPRLowAcc,d$MemAPRChAcc,d$MemAPRHighAcc,d$MemActLowAcc,d$MemActChAcc,d$MemActHighAcc,d$MemMemLowAcc,d$MemMemChAcc,d$MemMemHighAcc))

#Memory accuracy (0/1) for each attribute value, based on choice in primary choice task
mean(subset(d,ChoseDom==1)$MemAPRLowAcc)
mean(subset(d,ChoseAPR==1)$MemAPRLowAcc)
mean(subset(d,ChoseFix==1)$MemAPRLowAcc)
mean(subset(d,ChoseAct==1)$MemAPRLowAcc)

mean(subset(d,ChoseDom==1)$MemAPRChAcc)
mean(subset(d,ChoseAPR==1)$MemAPRChAcc)
mean(subset(d,ChoseFix==1)$MemAPRChAcc)
mean(subset(d,ChoseAct==1)$MemAPRChAcc)

mean(subset(d,ChoseDom==1)$MemAPRHighAcc)
mean(subset(d,ChoseAPR==1)$MemAPRHighAcc)
mean(subset(d,ChoseFix==1)$MemAPRHighAcc)
mean(subset(d,ChoseAct==1)$MemAPRHighAcc)

mean(subset(d,ChoseDom==1)$MemActLowAcc)
mean(subset(d,ChoseAPR==1)$MemActLowAcc)
mean(subset(d,ChoseFix==1)$MemActLowAcc)
mean(subset(d,ChoseAct==1)$MemActLowAcc)

mean(subset(d,ChoseDom==1)$MemActChAcc)
mean(subset(d,ChoseAPR==1)$MemActChAcc)
mean(subset(d,ChoseFix==1)$MemActChAcc)
mean(subset(d,ChoseAct==1)$MemActChAcc)

mean(subset(d,ChoseDom==1)$MemActHighAcc)
mean(subset(d,ChoseAPR==1)$MemActHighAcc)
mean(subset(d,ChoseFix==1)$MemActHighAcc)
mean(subset(d,ChoseAct==1)$MemActHighAcc)

mean(subset(d,ChoseDom==1)$MemMemLowAcc)
mean(subset(d,ChoseAPR==1)$MemMemLowAcc)
mean(subset(d,ChoseFix==1)$MemMemLowAcc)
mean(subset(d,ChoseAct==1)$MemMemLowAcc)

mean(subset(d,ChoseDom==1)$MemMemChAcc)
mean(subset(d,ChoseAPR==1)$MemMemChAcc)
mean(subset(d,ChoseFix==1)$MemMemChAcc)
mean(subset(d,ChoseAct==1)$MemMemChAcc)

mean(subset(d,ChoseDom==1)$MemMemHighAcc)
mean(subset(d,ChoseAPR==1)$MemMemHighAcc)
mean(subset(d,ChoseFix==1)$MemMemHighAcc)
mean(subset(d,ChoseAct==1)$MemMemHighAcc)

#Table 5 memory for key themes in video
summary(cbind(d$MemIss1,d$MemIss2,d$MemIss3,d$MemIss4,d$MemIss5))

####Attention and Choice####

#Choice of dominating card in main choice task as a function of video and ad
summary(glm(ChoseDom~VidCon*AdCon,data=d,family="binomial"))
xtabs(~d$Ad+d$ChoseDom)
xtabs(~d$Video+d$ChoseDom)

#Choice of dominating card in main choice task as a function of video, ad, and amount of attention and allocation of attention
summary(glm(ChoseDom~VidCon*AdCon*AvgLnTime+VidCon*AdCon*DiffLnTime,data=d,family="binomial"))
#Same model as above, highlighting simple effects of amount of attention for each Video condition
summary(glm(ChoseDom~VidCon+AdCon+
                     VidCon:AdCon+Video/AvgLnTime+AdCon:AvgLnTime+
                     VidCon:AdCon:AvgLnTime+
                     VidCon*AdCon*DiffLnTime,data=d,family="binomial"))

#Table 6
#Card choice by pricing & terms
table(d$ChoseDom)
table(d$ChoseAct)
table(d$ChoseFix)
table(d$ChoseAPR)

#Time spent on each set of pricing & terms
summary(d$TimeDomCard)
summary(d$TimeActCard)
summary(d$TimeFixCard)
summary(d$TimeAPRCard)

#Number of views of each set of pricing & terms
summary(d$ViewDomCard)
summary(d$ViewActCard)
summary(d$ViewFixCard)
summary(d$ViewAPRCard)

#Card choice by card position
table(d$ChosenCard)

#Time spent on each set of pricing & terms by card position
summary(d$RTotTime1)
summary(d$RTotTime2)
summary(d$RTotTime3)
summary(d$RTotTime4)

#Number of views of each set of pricing & terms by card position
summary(d$CountView1)
summary(d$CountView2)
summary(d$CountView3)
summary(d$CountView4)

#Card choice by superfluous ad, only among those who saw the superfluous ad (among those who didn't, couldn't have affected)
table(subset(d,AdCon==.5)$ChoseIntroR)
table(subset(d,AdCon==.5)$ChoseMinPay)
table(subset(d,AdCon==.5)$ChoseMemFee)
table(subset(d,AdCon==.5)$ChoseForFee)

#Time spent on each set of pricing & terms by superfluous ad, only among those who saw superfluous ads
summary(subset(d,AdCon==.5)$TimeIntroR)
summary(subset(d,AdCon==.5)$TimeMinPay)
summary(subset(d,AdCon==.5)$TimeMemFee)
summary(subset(d,AdCon==.5)$TimeForFee)

#Number of views of each set of pricing & terms by card position, only among those who saw superfluous ads
summary(subset(d,AdCon==.5)$ViewIntroR)
summary(subset(d,AdCon==.5)$ViewMinPay)
summary(subset(d,AdCon==.5)$ViewMemFee)
summary(subset(d,AdCon==.5)$ViewForFee)

#Table 7
#Average time by video and ad
summary(lm(AvgLnTime~VidCon*AdCon,data=d))
#Allocation of time by video and ad
summary(lm(DiffLnTime~VidCon*AdCon,data=d))

#Conditional effects of video for each ad condition on average time
summary(lm(AvgLnTime~Ad/VidCon,data=d))
#Conditional effects of ad for each video condition on average time
summary(lm(AvgLnTime~Video/AdCon,data=d))

#Table 8
#Average views by video and ad
summary(lm(AvgLnView~VidCon*AdCon,data=d))
#Allocation of views by video and ad
summary(lm(DiffLnView~VidCon*AdCon,data=d))

#Conditional effects of video for each ad condition on average views
summary(lm(AvgLnView~Ad/VidCon,data=d))
#Conditional effects of ad for each video condition on average views
summary(lm(AvgLnView~Video/AdCon,data=d))

#Table 9
#Choice of dominant card during main choice ask as a function of Video and Ad with average time and difference in time as covariates
summary(glm(ChoseDom~VidCon*AdCon+AvgLnTime+DiffLnTime,data=d,family="binomial"))
#Choice of dominant card during main choice ask as a function of Video and Ad with average views and difference in views as covariates
summary(glm(ChoseDom~VidCon*AdCon+AvgLnView+DiffLnView,data=d,family="binomial"))

#As stated in text, mediation analyses (below) conducted using Hayes' (2013) PROCESS macro
#This code effectively and independently replicates that analysis, showing convergence
#Small differences in bootstrapped confidence intervals are due to differences in resampling
#To get conditional effect confidence intervals, can rerun bootstrapping with dummy-codes rather than contrast codes

#Table 10
f <- function(dboot, i){
	dboot2 <- dboot[i,]
	a1<-lm(AvgLnTime~VidCon*AdCon,data=dboot2)$coef
	a2<-lm(DiffLnTime~VidCon*AdCon,data=dboot2)$coef
	b<-glm(ChoseDom~VidCon*AdCon+AvgLnTime+DiffLnTime,data=dboot2,family="binomial")$coef
	vid_a1b<-a1[2]*b[4]
	ad_a1b<-a1[3]*b[4]
	vidad_a1b<-a1[4]*b[4]
	vid_a2b<-a2[2]*b[5]
	ad_a2b<-a2[3]*b[5]
	vidad_a2b<-a2[4]*b[5]
	return(c(vid_a1b,ad_a1b,vidad_a1b,vid_a2b,ad_a2b,vidad_a2b))
}
dformed<-select(d,ChoseDom,VidCon,AdCon,AvgLnTime,DiffLnTime)
set.seed(07181984)
bootmed <- boot(dformed, f, R=10000)
#in order (1 to 6), results are indirect effects of 1) video via average, 2) ad via average, 3) interaction via average,
#4) video via difference, 5) ad via difference, 6) interaction via difference
bootmed
boot.ci(bootmed,index=1,type=c("bca"))
boot.ci(bootmed,index=2,type=c("bca"))
boot.ci(bootmed,index=3,type=c("bca"))
boot.ci(bootmed,index=4,type=c("bca"))
boot.ci(bootmed,index=5,type=c("bca"))
boot.ci(bootmed,index=6,type=c("bca"))

#Table 11
f <- function(dboot, i){
  dboot2 <- dboot[i,]
  a1<-lm(AvgLnView~VidCon*AdCon,data=dboot2)$coef
  a2<-lm(DiffLnView~VidCon*AdCon,data=dboot2)$coef
  b<-glm(ChoseDom~VidCon*AdCon+AvgLnView+DiffLnView,data=dboot2,family="binomial")$coef
  vid_a1b<-a1[2]*b[4]
  ad_a1b<-a1[3]*b[4]
  vidad_a1b<-a1[4]*b[4]
  vid_a2b<-a2[2]*b[5]
  ad_a2b<-a2[3]*b[5]
  vidad_a2b<-a2[4]*b[5]
  return(c(vid_a1b,ad_a1b,vidad_a1b,vid_a2b,ad_a2b,vidad_a2b))
}
dformed<-select(d,ChoseDom,VidCon,AdCon,AvgLnView,DiffLnView)
set.seed(07181984)
bootmed <- boot(dformed, f, R=10000)
#exactly analagous to above, except views rather than time
bootmed
boot.ci(bootmed,index=1,type=c("bca"))
boot.ci(bootmed,index=2,type=c("bca"))
boot.ci(bootmed,index=3,type=c("bca"))
boot.ci(bootmed,index=4,type=c("bca"))
boot.ci(bootmed,index=5,type=c("bca"))
boot.ci(bootmed,index=6,type=c("bca"))

#Figure 4
plotTimeTarget<-summarize(group_by(d[,c("Video","Ad","LnTimeDomCard")],Video,Ad),
                          Card=factor("Dominant"),
                          mTime=mean(LnTimeDomCard,na.rm=T),
                          seTime=sqrt(var(LnTimeDomCard,na.rm=TRUE)/length(na.omit(LnTimeDomCard))))
plotTimeOther<-summarize(group_by(d[,c("Video","Ad","AvgOtherLnTime")],Video,Ad),
                         Card=factor("Other"),
                         mTime=mean(AvgOtherLnTime,na.rm=T),
                         seTime=sqrt(var(AvgOtherLnTime,na.rm=TRUE)/length(na.omit(AvgOtherLnTime))))
plotTimeDiff<-summarize(group_by(d[,c("Video","Ad","DiffLnTime")],Video,Ad),
                        Card=factor("Difference"),
                        mTime=mean(DiffLnTime,na.rm=T),
                        seTime=sqrt(var(DiffLnTime,na.rm=TRUE)/length(na.omit(DiffLnTime))))
plotTime<-rbind(plotTimeTarget,plotTimeOther,plotTimeDiff)
plotTime$llTime<-plotTime$mTime-1.96*plotTime$seTime
plotTime$ulTime<-plotTime$mTime+1.96*plotTime$seTime
plotTime$VideoLab<-factor(ifelse(plotTime$Video=="Baseline","Baseline","Implemental"))
plotTime$VideoLab<-relevel(plotTime$VideoLab,"Baseline")
plotTime$AdLab<-ifelse(plotTime$Ad=="None","No Tagline","Superfluous Tagline")
ggplot(data=subset(plotTime,Card!="Difference"),aes(x=VideoLab,y=exp(mTime)-1,ymax=exp(ulTime)-1,ymin=exp(llTime)-1,
                                                    shape=Card,color=Card,linetype=Card))+
  geom_pointrange(size=1,position=position_dodge(width=.5))+
  scale_color_brewer(palette="Set1")+
  ylab("Time Spent Viewing Pricing and Terms (Seconds)")+
  xlab("")+
  ylim(0,25)+
  facet_grid(~AdLab)+
  theme_bw()
ggplot(data=subset(plotTime,Card=="Difference"),aes(x=VideoLab,y=exp(mTime),ymax=exp(ulTime),ymin=exp(llTime)))+
  geom_pointrange(size=1,position=position_dodge(width=.5))+
  scale_color_brewer(palette="Set1")+
  ylab("Ratio of Time Spent Viewing Pricing and Terms of Dominant vs. Other Cards")+
  xlab("")+
  ylim(1,1.5)+
  facet_grid(~AdLab)+
  theme_bw()

#Figure 5
plotViewTarget<-summarize(group_by(d[,c("Video","Ad","LnViewDomCard")],Video,Ad),
                          Card=factor("Dominant"),
                          mView=mean(LnViewDomCard,na.rm=T),
                          seView=sqrt(var(LnViewDomCard,na.rm=TRUE)/length(na.omit(LnViewDomCard))))
plotViewOther<-summarize(group_by(d[,c("Video","Ad","AvgOtherLnView")],Video,Ad),
                         Card=factor("Other"),
                         mView=mean(AvgOtherLnView,na.rm=T),
                         seView=sqrt(var(AvgOtherLnView,na.rm=TRUE)/length(na.omit(AvgOtherLnView))))
plotViewDiff<-summarize(group_by(d[,c("Video","Ad","DiffLnView")],Video,Ad),
                        Card=factor("Difference"),
                        mView=mean(DiffLnView,na.rm=T),
                        seView=sqrt(var(DiffLnView,na.rm=TRUE)/length(na.omit(DiffLnView))))
plotView<-rbind(plotViewTarget,plotViewOther,plotViewDiff)
plotView$llView<-plotView$mView-1.96*plotView$seView
plotView$ulView<-plotView$mView+1.96*plotView$seView
plotView$VideoLab<-factor(ifelse(plotView$Video=="Baseline","Baseline","Implemental"))
plotView$VideoLab<-relevel(plotView$VideoLab,"Baseline")
plotView$AdLab<-ifelse(plotView$Ad=="None","No Tagline","Superfluous Tagline")
ggplot(data=subset(plotView,Card!="Difference"),aes(x=VideoLab,y=exp(mView)-1,ymax=exp(ulView)-1,ymin=exp(llView)-1,
                                                    shape=Card,color=Card,linetype=Card))+
  geom_pointrange(size=1,position=position_dodge(width=.5))+
  scale_color_brewer(palette="Set1")+
  ylab("Views of Pricing and Terms")+
  xlab("")+
  ylim(0,4)+
  facet_grid(~AdLab)+
  theme_bw()
ggplot(data=subset(plotView,Card=="Difference"),aes(x=VideoLab,y=exp(mView),ymax=exp(ulView),ymin=exp(llView)))+
  geom_pointrange(size=1,position=position_dodge(width=.5))+
  scale_color_brewer(palette="Set1")+
  ylab("Ratio of Views of Pricing and Terms of Dominant vs. Other Cards")+
  xlab("")+
  ylim(1,1.5)+
  facet_grid(~AdLab)+
  theme_bw()

#Figure 6
xtabs(~d$Video+d$ChoseDom+d$Ad)
stacklab<-data.frame(rbind(cbind("Baseline","No Tagline",.21,.43),
                           cbind("Implemental","No Tagline",.32,.65),
                           cbind("Baseline","Superfluous Tagline",.18,.37),
                           cbind("Implemental","Superfluous Tagline",.25,.51)))
colnames(stacklab)<-c("VidLab","AdLab","YPos","ValLab")
stacklab$YPos<-as.numeric(as.character(stacklab$YPos))
stacklab$ValLab<-as.numeric(as.character(stacklab$ValLab))
ggplot(d,aes(x=factor(Video,levels=c("Baseline","Implemental")))) +
  geom_bar(aes(fill=factor(ChoseDom,levels=c(1,0))),position='fill',color="black") +
  geom_text(data=stacklab,aes(x=VidLab,y=YPos,label=ValLab))+
  scale_fill_manual(values=c("gray90","white"))+
  xlab("")+
  ylab("Choice Share of Dominant Card")+
  facet_grid(~AdLab)+
  theme_bw()+
  theme(legend.position="none")

####Perceptions and Attitudes toward Sharing####

#alpha of Special items
psych::alpha(data.frame(d$VidAttr_1,d$VidAttr_2,d$VidAttr_3,d$VidAttr_4,d$VidAttr_5),keys=c(1,4))
#alpha of Hedonic items
psych::alpha(data.frame(d$VidAttr_6,d$VidAttr_7,d$VidAttr_8,d$VidAttr_9),keys=c(2,4))
#alpha of Useful items
psych::alpha(data.frame(d$VidAttr_10,d$VidAttr_11,d$VidAttr_12,d$VidAttr_13),keys=c(1,2,3,4))
#alpha of Interesting items
psych::alpha(data.frame(d$VidAttr_14,d$VidAttr_15,d$VidAttr_16,d$VidAttr_17),keys=c(1,2,3,4))

#Each dimension (Special, Hedonic, Useful, Interesting), as a function of Video and Ad
summary(lm(Special~VidCon*AdCon,data=d))
summary(lm(Hedonic~VidCon*AdCon,data=d))
summary(lm(Useful~VidCon*AdCon,data=d))
summary(lm(Interesting~VidCon*AdCon,data=d))

#Sharing alpha and as a function of Video and Ad
psych::alpha(data.frame(d$WllngShare_1,d$WllngShare_2,d$WllngShare_3,d$LklyShare_1,d$LklyShare_2,d$LklyShare_3))
summary(lm(Share~VidCon*AdCon,data=d))

#Perceived Effectiveness alpha and as a function of Video and Ad, and as a function of Video, Ad, and Dominant Card Chosen
psych::alpha(data.frame(d$RateChoice_1,d$RateChoice_2,d$RateChoice_3,d$RateChoice_4))
summary(lm(RateChoice~VidCon*AdCon,data=d))
summary(lm(RateChoice~VidCon*AdCon*ChoseDom,data=d))

#Sharing as a function of video and ad, controlling for perceived effectiveness
summary(lm(Share~VidCon*AdCon+RateChoice,data=d))

#Sharing as a function of video and ad, controlling for average and difference in time
summary(lm(Share~VidCon*AdCon+AvgLnTime+DiffLnTime,data=d))
#Sharing as a function of video and ad, controlling for choice of dominant card
summary(lm(Share~VidCon*AdCon+ChoseDom,data=d))

#Sharing as a function of video and ad, controlling for average and difference in time and perceived effectiveness
summary(lm(Share~VidCon*AdCon+AvgLnTime+DiffLnTime+RateChoice,data=d))
#Sharing as a function of video and ad, controlling for choice of dominant card and perceived effectiveness
summary(lm(Share~VidCon*AdCon+ChoseDom+RateChoice,data=d))

#Likelihood of applying for a credit card as a function of video and ad
summary(lm(ApplyLikel~VidCon*AdCon,data=d))

#Table 12
#Perceived effectiveness as a function of video and ad
summary(lm(RateChoice~VidCon*AdCon,data=d))
#Sharing as a function of video and ad, controlling for perceived effectiveness
summary(lm(Share~VidCon*AdCon+RateChoice,data=d))

#Table 13
#As above, these results vary very slightly from those in the paper due to differences in resampling.
#Again, can elicit bootstrapped conditional effects by replacing Contrast codes with 0-1 dummy codes
f <- function(dboot, i){
  dboot2 <- dboot[i,]
  a<-lm(RateChoice~VidCon*AdCon,data=dboot2)$coef
  b<-lm(Share~VidCon*AdCon+RateChoice,data=dboot2)$coef
  vid<-a[2]*b[4]
  ad<-a[3]*b[4]
  vidad<-a[4]*b[4]
  return(c(vid,ad,vidad))
}
dformed<-select(d,Share,VidCon,AdCon,RateChoice)
set.seed(07181984)
bootmed <- boot(dformed, f, R=10000)
#In order, indirect effects represent:
#) video via perceived effectiveness, 2) ad via perceived effectiveness, 3) interaction via perceived effectiveness
bootmed
boot.ci(bootmed,index=1,type=c("bca"))
boot.ci(bootmed,index=2,type=c("bca"))
boot.ci(bootmed,index=3,type=c("bca"))
