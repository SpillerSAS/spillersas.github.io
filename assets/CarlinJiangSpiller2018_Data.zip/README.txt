The datafile, codebook, and analysis file supplement “Millennial-Style Learning: Search Intensity, Decision-Making, and Information-Sharing” by Carlin, Jiang, and Spiller.

“CJSData.csv” contains the data (N = 1603) on which all analyses are based. This datafile includes some variables collected in their raw format (e.g., “Track”) as well as those calculated based on those variables for analysis (e.g., “TimeDomCard” based on “Track”). In other cases, only the recoded variable is included (e.g., “MemAPRChose” was based on a recoding of the raw input, keeping only numeric responses.)

“CJSCodebook.xlsx” contains a full list of variable names included in the datafile “CJSData.csv”, along with their interpretations. 

“CJSAnalysis.R” contains R code for conducting the analyses. 

The datafile excludes browser data, open-ended text responses, and ethnicity to preserve anonymity.